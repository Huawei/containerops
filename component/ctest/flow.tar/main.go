
package main

import (
	"fmt"
	"os"

)


func main() {

	fmt.Fprintf(os.Stdout, "[COUT] CO_RESULT = %s\n", "false")
	
}
